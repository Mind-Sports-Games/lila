# IMPORTANT - Do not modify these files!

They are generated, and will be overwritten.

### Instead, [use Crowdin to contribute to playstrategy translations](https://crowdin.com/project/playstrategy).

Thank you!
